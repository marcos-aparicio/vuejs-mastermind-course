<template>
  <nav class="navbar bg-base-200 shadow-sm">
    Ilia topuria
    <div class="flex-1">
      <div class="avatar">
        <div class="w-8">
          <img src="@/assets/logo.svg" alt="logo" />
        </div>
      </div>
    </div>
    <span>Todo List App</span>
  </nav>
</template>
